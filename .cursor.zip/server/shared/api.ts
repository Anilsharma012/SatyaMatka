export interface DemoResponse {
  message: string;
}
