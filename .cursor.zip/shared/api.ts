export interface DemoResponse {
  message: string;
}

export interface PingResponse {
  message: string;
}
