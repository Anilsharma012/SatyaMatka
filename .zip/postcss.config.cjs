// ✅ CommonJS format (works everywhere including Netlify)
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
